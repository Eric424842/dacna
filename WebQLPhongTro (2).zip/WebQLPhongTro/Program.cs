﻿using Microsoft.EntityFrameworkCore;
using WebQLPhongTro.Repository;
using WebQLPhongTro.Models;

namespace WebQLPhongTro
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Cấu hình dịch vụ MVC và API
            builder.Services.AddControllersWithViews();
            builder.Services.AddControllers(); // Thêm hỗ trợ API controllers

            // Lấy chuỗi kết nối từ appsettings.json
            var connectionString = builder.Configuration.GetConnectionString("MySqlConn");

            // Cấu hình DbContext với MySQL
            builder.Services.AddDbContext<DataContext>(options =>
            {
                options.UseMySql(connectionString, ServerVersion.AutoDetect(connectionString));
            });

            // Cấu hình CORS nếu cần (nếu frontend và backend trên cùng origin, không cần)
            builder.Services.AddCors(options =>
            {
                options.AddPolicy("AllowAll",
                    builder =>
                    {
                        builder.AllowAnyOrigin()
                               .AllowAnyMethod()
                               .AllowAnyHeader();
                    });
            });

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseCors("AllowAll"); // Sử dụng CORS nếu đã cấu hình

            app.UseAuthorization();

            // Map API controllers
            app.MapControllers();

            // Map MVC controllers
            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}");

            // Call SeedData to add initial data
            using (var scope = app.Services.CreateScope())
            {
                var dataContext = scope.ServiceProvider.GetRequiredService<DataContext>();
                SeedData.SeedingData(dataContext); // Gọi phương thức SeedingData để thêm dữ liệu mẫu
            }

            app.Run();
        }
    }
}
