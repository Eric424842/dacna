﻿Vue.use(Buefy.default);

new Vue({
    el: '#app',
    data: {
        rooms: window.roomData || [],
        defaultOpenedDetails: [],
        showDetailIcon: true,
        selectedBeds: {}
    },
    methods: {
        toggle(row) {
            this.$refs.table.toggleDetails(row);
        },
        formatPrice(value) {
            if (isNaN(value)) {
                console.error('Invalid price value:', value);
                return 'NaN ₫ VND';
            }
            return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(value);
        },
        getOddBeds(beds) {
            return beds.filter(bed => bed.bedNumber % 2 !== 0);
        },
        getEvenBeds(beds) {
            return beds.filter(bed => bed.bedNumber % 2 === 0);
        }
    },
    created() {
        console.log('Vue instance created');
        console.log('Rooms data:', this.rooms);
    }
});
