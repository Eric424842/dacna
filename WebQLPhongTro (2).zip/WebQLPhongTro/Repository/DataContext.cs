﻿using Microsoft.EntityFrameworkCore;

namespace WebQLPhongTro.Models
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options) : base(options)
        {
        }

        public DbSet<BranchModel> Branches { get; set; }
        public DbSet<RoomModel> Rooms { get; set; }
        public DbSet<BedModel> Beds { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Thiết lập mối quan hệ một-nhiều giữa Branch và Room
            modelBuilder.Entity<BranchModel>()
                .HasMany(b => b.Rooms)
                .WithOne(r => r.Branch)
                .HasForeignKey(r => r.BranchId)
                .OnDelete(DeleteBehavior.Cascade);

            // Thiết lập mối quan hệ một-nhiều giữa Room và Bed
            modelBuilder.Entity<RoomModel>()
                .HasMany(r => r.Beds)
                .WithOne(b => b.Room)
                .HasForeignKey(b => b.RoomId)
                .OnDelete(DeleteBehavior.Cascade);

            // Cấu hình Enum BedStatus dưới dạng chuỗi
            modelBuilder.Entity<BedModel>()
                .Property(b => b.Status)
                .HasConversion<string>();
        }
    }
}
