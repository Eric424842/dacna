﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebQLPhongTro.Models;
using WebQLPhongTro.Repository;


namespace WebQLPhongTro.Repository.Component
{
    public class RoomsViewComponent : ViewComponent
    {
        private readonly DataContext _dataContext;
        public RoomsViewComponent(DataContext context)
        {
            _dataContext = context;
        }
        public async Task<IViewComponentResult> InvokeAsync() => View(await _dataContext.Rooms.ToListAsync());
    }
}
