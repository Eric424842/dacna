﻿using Microsoft.EntityFrameworkCore;
using WebQLPhongTro.Models;
using System.Collections.Generic;
using System.Linq;

namespace WebQLPhongTro.Repository
{
    public class SeedData
    {
        public static void SeedingData(DataContext context)
        {
            // Áp dụng các migrations nếu chưa được áp dụng
            context.Database.Migrate();

            // Kiểm tra xem đã có dữ liệu chưa để tránh trùng lặp
            if (!context.Branches.Any())
            {
                // Seed dữ liệu cho BranchModel
                var branches = new List<BranchModel>
                {
                    new BranchModel
                    {
                        Name = "Quang Trung",
                        Address = "Đường số 3, CVPM Quang Trung",
                        Ward = "P Tân Chánh Hiệp",
                        District = "Q12",
                        Slug = "quang-trung",
                        TelePhoneNumber = "0258741369",
                        ImagePath = "/images/branches/quang-trung.jpg", // Đường dẫn tương đối
                        Rooms = new List<RoomModel>
                        {
                            new RoomModel
                            {
                                Name = "Phòng 101",
                                Type = "Deluxe",
                                Area = "30m²",
                                Bathroom = 2,
                                BedQuantity = 4,
                                Price = 1000000m,
                                Beds = new List<BedModel>
                                {
                                    new BedModel { BedNumber = 1, Status = BedStatus.Available },
                                    new BedModel { BedNumber = 2, Status = BedStatus.Occupied },
                                    new BedModel { BedNumber = 3, Status = BedStatus.Available },
                                    new BedModel { BedNumber = 4, Status = BedStatus.Available }
                                }
                            },
                            new RoomModel
                            {
                                Name = "Phòng 102",
                                Type = "Standard",
                                Area = "25m²",
                                Bathroom = 1,
                                BedQuantity = 3,
                                Price = 700000m,
                                Beds = new List<BedModel>
                                {
                                    new BedModel { BedNumber = 1, Status = BedStatus.Available },
                                    new BedModel { BedNumber = 2, Status = BedStatus.Occupied },
                                    new BedModel { BedNumber = 3, Status = BedStatus.Reserved }
                                }
                            },
                            new RoomModel
                            {
                                Name = "Phòng 103",
                                Type = "Suite",
                                Area = "40m²",
                                Bathroom = 2,
                                BedQuantity = 5,
                                Price = 1500000m,
                                Beds = new List<BedModel>
                                {
                                    new BedModel { BedNumber = 1, Status = BedStatus.Available },
                                    new BedModel { BedNumber = 2, Status = BedStatus.Occupied },
                                    new BedModel { BedNumber = 3, Status = BedStatus.Available },
                                    new BedModel { BedNumber = 4, Status = BedStatus.Available },
                                    new BedModel { BedNumber = 5, Status = BedStatus.Reserved }
                                }
                            }
                        }
                    },
                    new BranchModel
                    {
                        Name = "Nguyễn Văn Tráng",
                        Address = "08 Nguyễn Văn Tráng",
                        Ward = "P Bến Thành",
                        District = "Q1",
                        Slug = "nguyen-van-trang",
                        TelePhoneNumber = "0917424842",
                        ImagePath = "/images/branches/nguyen-van-trang.jpg",
                        Rooms = new List<RoomModel>
                        {
                            new RoomModel
                            {
                                Name = "Phòng 201",
                                Type = "Deluxe",
                                Area = "32m²",
                                Bathroom = 2,
                                BedQuantity = 4,
                                Price = 1200000m,
                                Beds = new List<BedModel>
                                {
                                    new BedModel { BedNumber = 1, Status = BedStatus.Available },
                                    new BedModel { BedNumber = 2, Status = BedStatus.Available },
                                    new BedModel { BedNumber = 3, Status = BedStatus.Occupied },
                                    new BedModel { BedNumber = 4, Status = BedStatus.Reserved }
                                }
                            },
                            new RoomModel
                            {
                                Name = "Phòng 202",
                                Type = "Standard",
                                Area = "28m²",
                                Bathroom = 1,
                                BedQuantity = 2,
                                Price = 800000m,
                                Beds = new List<BedModel>
                                {
                                    new BedModel { BedNumber = 1, Status = BedStatus.Available },
                                    new BedModel { BedNumber = 2, Status = BedStatus.Occupied }
                                }
                            },
                            new RoomModel
                            {
                                Name = "Phòng 203",
                                Type = "Suite",
                                Area = "35m²",
                                Bathroom = 2,
                                BedQuantity = 5,
                                Price = 1600000m,
                                Beds = new List<BedModel>
                                {
                                    new BedModel { BedNumber = 1, Status = BedStatus.Available },
                                    new BedModel { BedNumber = 2, Status = BedStatus.Occupied },
                                    new BedModel { BedNumber = 3, Status = BedStatus.Reserved },
                                    new BedModel { BedNumber = 4, Status = BedStatus.Available },
                                    new BedModel { BedNumber = 5, Status = BedStatus.Available }
                                }
                            }
                        }
                    },
                    new BranchModel
                    {
                        Name = "Cao Thắng",
                        Address = "93 Cao Thắng",
                        Ward = "P3",
                        District = "Q3",
                        Slug = "cao-thang",
                        TelePhoneNumber = "0974782537",
                        ImagePath = "/images/branches/cao-thang.jpg",
                        Rooms = new List<RoomModel>
                        {
                            new RoomModel
                            {
                                Name = "Phòng 301",
                                Type = "Standard",
                                Area = "26m²",
                                Bathroom = 1,
                                BedQuantity = 3,
                                Price = 900000m,
                                Beds = new List<BedModel>
                                {
                                    new BedModel { BedNumber = 1, Status = BedStatus.Available },
                                    new BedModel { BedNumber = 2, Status = BedStatus.Occupied },
                                    new BedModel { BedNumber = 3, Status = BedStatus.Reserved }
                                }
                            },
                            new RoomModel
                            {
                                Name = "Phòng 302",
                                Type = "Suite",
                                Area = "45m²",
                                Bathroom = 2,
                                BedQuantity = 5,
                                Price = 1500000m,
                                Beds = new List<BedModel>
                                {
                                    new BedModel { BedNumber = 1, Status = BedStatus.Available },
                                    new BedModel { BedNumber = 2, Status = BedStatus.Available },
                                    new BedModel { BedNumber = 3, Status = BedStatus.Occupied },
                                    new BedModel { BedNumber = 4, Status = BedStatus.Available },
                                    new BedModel { BedNumber = 5, Status = BedStatus.Reserved }
                                }
                            },
                            new RoomModel
                            {
                                Name = "Phòng 303",
                                Type = "Deluxe",
                                Area = "35m²",
                                Bathroom = 1,
                                BedQuantity = 4,
                                Price = 1100000m,
                                Beds = new List<BedModel>
                                {
                                    new BedModel { BedNumber = 1, Status = BedStatus.Available },
                                    new BedModel { BedNumber = 2, Status = BedStatus.Occupied },
                                    new BedModel { BedNumber = 3, Status = BedStatus.Reserved },
                                    new BedModel { BedNumber = 4, Status = BedStatus.Available }
                                }
                            },
                            new RoomModel
                            {
                                Name = "Phòng 304",
                                Type = "Deluxe",
                                Area = "38m²",
                                Bathroom = 2,
                                BedQuantity = 5,
                                Price = 1300000m,
                                Beds = new List<BedModel>
                                {
                                    new BedModel { BedNumber = 1, Status = BedStatus.Available },
                                    new BedModel { BedNumber = 2, Status = BedStatus.Occupied },
                                    new BedModel { BedNumber = 3, Status = BedStatus.Reserved },
                                    new BedModel { BedNumber = 4, Status = BedStatus.Available },
                                    new BedModel { BedNumber = 5, Status = BedStatus.Available }
                                }
                            }
                        }
                    }
                };

                // Thêm các chi nhánh vào database
                context.Branches.AddRange(branches);
                context.SaveChanges();
            }
        }
    }
}
