﻿using Microsoft.AspNetCore.Mvc;
using WebQLPhongTro.Models;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace WebQLPhongTro.Controllers
{
    public class BranchController : Controller
    {
        private readonly DataContext _context;

        public BranchController(DataContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var branches = _context.Branches.ToList();
            return View(branches);
        }

        // Hiển thị chi tiết chi nhánh
        public IActionResult Details(int id)
        {
            var branch = _context.Branches.FirstOrDefault(b => b.Id == id);
            if (branch == null)
            {
                return NotFound();
            }
            return View(branch);
        }

        // Chọn chi nhánh
        public IActionResult SelectBranch(int id)
        {
            // Logic để chọn chi nhánh, ví dụ: lưu vào session hoặc chuyển hướng đến quản lý phòng trọ
            // ...
            return RedirectToAction("Index", "Room", new { branchId = id });
        }
    }
}
