﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;
using WebQLPhongTro.Models;
using System.Collections.Generic;

namespace WebQLPhongTro.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ApiController : ControllerBase
    {
        private readonly DataContext _context;
        private readonly ILogger<ApiController> _logger;

        public ApiController(DataContext context, ILogger<ApiController> logger)
        {
            _context = context;
            _logger = logger;
        }

        // GET: api/Api/GetRooms?branchId=1
        [HttpGet("GetRooms")]
        public async Task<IActionResult> GetRooms(int branchId)
        {
            if (branchId == 0)
            {
                _logger.LogWarning("BranchId is missing in GetRooms request.");
                return BadRequest("BranchId is required");
            }

            var rooms = await _context.Rooms
                .Where(r => r.BranchId == branchId)
                .Include(r => r.Beds)
                .ToListAsync();

            if (!rooms.Any())
            {
                _logger.LogInformation($"No rooms found for BranchId {branchId}.");
            }

            var result = rooms.Select(r => new
            {
                r.Id,
                r.Name,
                r.Type,
                r.Area,
                r.Bathroom,
                r.BedQuantity,
                r.Price,
                Beds = r.Beds.Select(b => new {
                    b.BedNumber,
                    b.Status
                }).ToList()
            });

            _logger.LogInformation($"Returning {result.Count()} rooms for BranchId {branchId}.");
            return Ok(result);
        }

        // POST: api/Api/UpdateSelectedBeds
        [HttpPost("UpdateSelectedBeds")]
        public async Task<IActionResult> UpdateSelectedBeds([FromBody] UpdateBedsRequest request)
        {
            if (request == null || request.RoomId == 0)
            {
                return BadRequest("Invalid request");
            }

            var room = await _context.Rooms.Include(r => r.Beds).FirstOrDefaultAsync(r => r.Id == request.RoomId);
            if (room == null)
            {
                return NotFound("Room not found");
            }

            // Cập nhật trạng thái các giường
            foreach (var bed in room.Beds)
            {
                if (request.SelectedBeds.Contains(bed.BedNumber))
                {
                    bed.Status = BedStatus.Reserved; // Hoặc trạng thái phù hợp
                }
                else if (bed.Status == BedStatus.Reserved)
                {
                    bed.Status = BedStatus.Available; // Giữ nguyên trạng thái nếu không được chọn
                }
            }

            await _context.SaveChangesAsync();

            return Ok(new { success = true });
        }
    }

    // Lớp Request để nhận dữ liệu từ frontend
    public class UpdateBedsRequest
    {
        public int RoomId { get; set; }
        public List<int> SelectedBeds { get; set; }
    }
}
