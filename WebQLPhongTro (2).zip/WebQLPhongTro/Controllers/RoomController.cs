﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;
using WebQLPhongTro.Models;

namespace WebQLPhongTro.Controllers
{
    public class RoomController : Controller
    {
        private readonly DataContext _context;

        public RoomController(DataContext context)
        {
            _context = context;
        }

        // GET: /Room?branchId=1
        public async Task<IActionResult> Index(int branchId)
        {
            if (branchId == 0)
            {
                return BadRequest("BranchId is required");
            }

            var branch = await _context.Branches.FindAsync(branchId);
            if (branch == null)
            {
                return NotFound("Branch not found");
            }

            ViewBag.BranchName = branch.Name;
            ViewBag.BranchId = branchId;

            return View();
        }
    }
}
