﻿using System.Collections.Generic;
using WebQLPhongTro.Models.ViewModels;

namespace WebQLPhongTro.ViewModels
{
    public class RoomViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public string Area { get; set; }
        public int Bathroom { get; set; }
        public int BedQuantity { get; set; }
        public decimal Price { get; set; }
        public List<int> OccupiedBeds { get; set; }
        public List<int> SelectedBeds { get; set; } = new List<int>();
    }

}
