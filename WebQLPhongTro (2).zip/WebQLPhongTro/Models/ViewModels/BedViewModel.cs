﻿namespace WebQLPhongTro.Models.ViewModels
{
    public class BedViewModel
    {
        public int Id { get; set; }
        public int BedNumber { get; set; }
        public string Status { get; set; }
    }
}
