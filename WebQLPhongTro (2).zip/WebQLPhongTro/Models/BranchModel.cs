﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace WebQLPhongTro.Models
{
    public class BranchModel
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Yêu cầu nhập tên Chi Nhánh")]
        [MaxLength(50, ErrorMessage = "Tên Chi Nhánh không được vượt quá 50 ký tự")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Yêu cầu nhập tên đường")]
        [MaxLength(100, ErrorMessage = "Địa chỉ không được vượt quá 100 ký tự")]
        public string Address { get; set; }

        [Required(ErrorMessage = "Yêu cầu nhập tên Phường")]
        [MaxLength(50, ErrorMessage = "Tên Phường không được vượt quá 50 ký tự")]
        public string Ward { get; set; }

        [Required(ErrorMessage = "Yêu cầu nhập tên Quận")]
        [MaxLength(50, ErrorMessage = "Tên Quận không được vượt quá 50 ký tự")]
        public string District { get; set; }

        [Required(ErrorMessage = "Yêu cầu nhập Slug")]
        [MaxLength(100, ErrorMessage = "Slug không được vượt quá 100 ký tự")]
        public string Slug { get; set; }

        [Required(ErrorMessage = "Yêu cầu nhập số điện thoại")]
        [Phone(ErrorMessage = "Số điện thoại không hợp lệ")]
        [MaxLength(12, ErrorMessage = "Số điện thoại không được vượt quá 12 ký tự")]
        public string TelePhoneNumber { get; set; }

        public string ImagePath { get; set; }

        // Thuộc tính navigation
        public ICollection<RoomModel> Rooms { get; set; } = new List<RoomModel>();
    }
}
