﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebQLPhongTro.Models
{
    public enum BedStatus
    {
        Available,
        Occupied,
        UnderRepair,
        Closed,
        Reserved
    }

    public class BedModel
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [ForeignKey("Room")]
        public int RoomId { get; set; }

        public RoomModel Room { get; set; }

        [Required]
        [Range(1, 100, ErrorMessage = "Số thứ tự giường phải từ 1 đến 100")]
        public int BedNumber { get; set; }

        [Required]
        public BedStatus Status { get; set; } // Available, Occupied, Reserved, UnderRepair, Closed
    }
}
