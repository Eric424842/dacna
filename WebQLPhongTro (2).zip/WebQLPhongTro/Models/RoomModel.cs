﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebQLPhongTro.Models
{
    public class RoomModel
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Yêu cầu chọn Chi Nhánh")]
        [ForeignKey("Branch")]
        public int BranchId { get; set; }

        public BranchModel Branch { get; set; }

        [Required(ErrorMessage = "Yêu cầu nhập tên Phòng")]
        [MaxLength(50, ErrorMessage = "Tên Phòng không được vượt quá 50 ký tự")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Yêu cầu chọn loại Phòng")]
        [MaxLength(50, ErrorMessage = "Loại Phòng không được vượt quá 50 ký tự")]
        public string Type { get; set; }

        [Required(ErrorMessage = "Yêu cầu nhập diện tích Phòng")]
        [MaxLength(20, ErrorMessage = "Diện Tích không được vượt quá 20 ký tự")]
        public string Area { get; set; }

        [Required(ErrorMessage = "Yêu cầu nhập số lượng phòng vệ sinh")]
        [Range(0, 10, ErrorMessage = "Số lượng phòng vệ sinh phải từ 0 đến 10")]
        public int Bathroom { get; set; }

        [Required(ErrorMessage = "Yêu cầu nhập số lượng giường")]
        [Range(1, 20, ErrorMessage = "Số lượng giường phải từ 1 đến 20")]
        public int BedQuantity { get; set; }

        [Required(ErrorMessage = "Yêu cầu nhập đơn giá phòng")]
        [Range(0, double.MaxValue, ErrorMessage = "Đơn giá phòng phải là số dương")]
        public decimal Price { get; set; }

        [Required(ErrorMessage = "Yêu cầu nhập trạng thái Phòng")]
        [MaxLength(20, ErrorMessage = "Trạng Thái Phòng không được vượt quá 20 ký tự")]

        // Navigation Property
        public ICollection<BedModel> Beds { get; set; } = new List<BedModel>();
    }
}
